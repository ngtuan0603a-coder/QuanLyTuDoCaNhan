Imports System.Windows.Forms
Imports System.Data.SqlClient

Namespace QLTuDoCaNhanVB
    Public Class FormNguoiDung
        Inherits Form

        Private dgv As New DataGridView() With {.Dock = DockStyle.Fill}
        Private txtTen As New TextBox()
        Private txtEmail As New TextBox()
        Private txtMK As New TextBox()
        Private btnThem As New Button() With {.Text = "Thêm"}
        Private btnSua As New Button() With {.Text = "Sửa"}
        Private btnXoa As New Button() With {.Text = "Xóa"}
        Private btnReload As New Button() With {.Text = "Làm mới"}

        Public Sub New()
            Me.Text = "Người dùng"
            Me.Width = 800
            Me.Height = 500

            Dim panel As New FlowLayoutPanel() With {.Dock = DockStyle.Top, .Height = 100}
            panel.Controls.AddRange({New Label() With {.Text = "Tên"}, txtTen,
                                     New Label() With {.Text = "Email"}, txtEmail,
                                     New Label() With {.Text = "Mật khẩu"}, txtMK,
                                     btnThem, btnSua, btnXoa, btnReload})

            Me.Controls.Add(dgv)
            Me.Controls.Add(panel)

            AddHandler Me.Load, AddressOf LoadData
            AddHandler btnThem.Click, AddressOf Them
            AddHandler btnSua.Click, AddressOf Sua
            AddHandler btnXoa.Click, AddressOf Xoa
            AddHandler btnReload.Click, AddressOf LoadData
        End Sub

        Private Sub LoadData(sender As Object, e As EventArgs)
            dgv.DataSource = Database.GetDataTable("SELECT * FROM NguoiDung")
        End Sub

        Private Sub Them(sender As Object, e As EventArgs)
            Dim sql = "INSERT INTO NguoiDung (TenNguoiDung, Email, MatKhau) VALUES (@Ten,@Email,@MK)"
            Dim p = New List(Of SqlParameter) From {
                New SqlParameter("@Ten", txtTen.Text),
                New SqlParameter("@Email", txtEmail.Text),
                New SqlParameter("@MK", txtMK.Text)}
            Database.ExecuteNonQuery(sql, p)
            LoadData(Nothing, Nothing)
        End Sub

        Private Sub Sua(sender As Object, e As EventArgs)
            If dgv.CurrentRow Is Nothing Then Return
            Dim id = dgv.CurrentRow.Cells("MaNguoiDung").Value
            Dim sql = "UPDATE NguoiDung SET TenNguoiDung=@Ten, Email=@Email, MatKhau=@MK WHERE MaNguoiDung=@ID"
            Dim p = New List(Of SqlParameter) From {
                New SqlParameter("@Ten", txtTen.Text),
                New SqlParameter("@Email", txtEmail.Text),
                New SqlParameter("@MK", txtMK.Text),
                New SqlParameter("@ID", id)}
            Database.ExecuteNonQuery(sql, p)
            LoadData(Nothing, Nothing)
        End Sub

        Private Sub Xoa(sender As Object, e As EventArgs)
            If dgv.CurrentRow Is Nothing Then Return
            Dim id = dgv.CurrentRow.Cells("MaNguoiDung").Value
            Database.ExecuteNonQuery("DELETE FROM NguoiDung WHERE MaNguoiDung=@ID",
                                     New List(Of SqlParameter) From {New SqlParameter("@ID", id)})
            LoadData(Nothing, Nothing)
        End Sub
    End Class
End Namespace
