Imports System.Windows.Forms

Namespace QLTuDoCaNhanVB
    Public Class MainForm
        Inherits Form

        Private menu As MenuStrip
        Private menuNguoiDung As ToolStripMenuItem
        Private menuTuDo As ToolStripMenuItem
        Private menuDoDung As ToolStripMenuItem
        Private menuLoaiDo As ToolStripMenuItem
        Private menuLichSu As ToolStripMenuItem

        Public Sub New()
            Me.Text = "Quản Lý Tủ Đồ Cá Nhân"
            Me.Width = 1000
            Me.Height = 700

            menu = New MenuStrip()
            menuNguoiDung = New ToolStripMenuItem("Người dùng")
            menuTuDo = New ToolStripMenuItem("Tủ đồ")
            menuDoDung = New ToolStripMenuItem("Đồ dùng")
            menuLoaiDo = New ToolStripMenuItem("Loại đồ")
            menuLichSu = New ToolStripMenuItem("Lịch sử")

            menu.Items.AddRange(New ToolStripItem() {menuNguoiDung, menuTuDo, menuDoDung, menuLoaiDo, menuLichSu})
            Me.MainMenuStrip = menu
            Me.Controls.Add(menu)

            AddHandler menuNguoiDung.Click, Sub() (New FormNguoiDung()).ShowDialog()
            AddHandler menuTuDo.Click, Sub() (New FormTuDo()).ShowDialog()
            AddHandler menuDoDung.Click, Sub() (New FormDoDung()).ShowDialog()
            AddHandler menuLoaiDo.Click, Sub() (New FormLoaiDo()).ShowDialog()
            AddHandler menuLichSu.Click, Sub() (New FormLichSu()).ShowDialog()
        End Sub
    End Class
End Namespace
