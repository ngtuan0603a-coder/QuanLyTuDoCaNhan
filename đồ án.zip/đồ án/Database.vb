Imports System.Data
Imports System.Data.SqlClient

Namespace QLTuDoCaNhanVB
    Public Module Database
        Public Property ConnectionString As String =
            "Server=LAPTOP-8LDKGUS9\SQLEXPRESS;Database=QLTuDoCaNhan;Integrated Security=True"

        Public Function GetDataTable(query As String) As DataTable
            Dim dt As New DataTable()
            Using conn As New SqlConnection(ConnectionString)
                Using da As New SqlDataAdapter(query, conn)
                    da.Fill(dt)
                End Using
            End Using
            Return dt
        End Function

        Public Sub ExecuteNonQuery(query As String, params As List(Of SqlParameter))
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()
                Using cmd As New SqlCommand(query, conn)
                    If params IsNot Nothing Then cmd.Parameters.AddRange(params.ToArray())
                    cmd.ExecuteNonQuery()
                End Using
            End Using
        End Sub
    End Module
End Namespace
