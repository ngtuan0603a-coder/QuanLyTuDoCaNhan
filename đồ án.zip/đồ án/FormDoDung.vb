Imports System.Windows.Forms
Imports System.Data.SqlClient

Namespace QLTuDoCaNhanVB
    Public Class FormDoDung
        Inherits Form

        Private dgv As New DataGridView() With {.Dock = DockStyle.Fill}
        Private txtTen As New TextBox()
        Private txtMoTa As New TextBox()
        Private txtLoai As New TextBox()
        Private txtTuDo As New TextBox()
        Private btnThem As New Button() With {.Text = "Thêm"}
        Private btnSua As New Button() With {.Text = "Sửa"}
        Private btnXoa As New Button() With {.Text = "Xóa"}
        Private btnReload As New Button() With {.Text = "Làm mới"}

        Public Sub New()
            Me.Text = "Đồ dùng"
            Me.Width = 900
            Me.Height = 500

            Dim panel As New FlowLayoutPanel() With {.Dock = DockStyle.Top, .Height = 100}
            panel.Controls.AddRange({
                New Label() With {.Text = "Tên đồ"}, txtTen,
                New Label() With {.Text = "Mô tả"}, txtMoTa,
                New Label() With {.Text = "Mã loại"}, txtLoai,
                New Label() With {.Text = "Mã tủ"}, txtTuDo,
                btnThem, btnSua, btnXoa, btnReload
            })

            Me.Controls.Add(dgv)
            Me.Controls.Add(panel)

            AddHandler Me.Load, AddressOf LoadData
            AddHandler btnThem.Click, AddressOf Them
            AddHandler btnSua.Click, AddressOf Sua
            AddHandler btnXoa.Click, AddressOf Xoa
            AddHandler btnReload.Click, AddressOf LoadData
        End Sub

        Private Sub LoadData(sender As Object, e As EventArgs)
            dgv.DataSource = Database.GetDataTable("SELECT * FROM DoDung")
        End Sub

        Private Sub Them(sender As Object, e As EventArgs)
            Dim sql = "INSERT INTO DoDung (TenDoDung, MoTa, MaLoaiDo, MaTuDo) VALUES (@Ten,@MoTa,@Loai,@Tu)"
            Dim p = New List(Of SqlParameter) From {
                New SqlParameter("@Ten", txtTen.Text),
                New SqlParameter("@MoTa", txtMoTa.Text),
                New SqlParameter("@Loai", txtLoai.Text),
                New SqlParameter("@Tu", txtTuDo.Text)}
            Database.ExecuteNonQuery(sql, p)
            LoadData(Nothing, Nothing)
        End Sub

        Private Sub Sua(sender As Object, e As EventArgs)
            If dgv.CurrentRow Is Nothing Then Return
            Dim id = dgv.CurrentRow.Cells("MaDoDung").Value
            Dim sql = "UPDATE DoDung SET TenDoDung=@Ten, MoTa=@MoTa, MaLoaiDo=@Loai, MaTuDo=@Tu WHERE MaDoDung=@ID"
            Dim p = New List(Of SqlParameter) From {
                New SqlParameter("@Ten", txtTen.Text),
                New SqlParameter("@MoTa", txtMoTa.Text),
                New SqlParameter("@Loai", txtLoai.Text),
                New SqlParameter("@Tu", txtTuDo.Text),
                New SqlParameter("@ID", id)}
            Database.ExecuteNonQuery(sql, p)
            LoadData(Nothing, Nothing)
        End Sub

        Private Sub Xoa(sender As Object, e As EventArgs)
            If dgv.CurrentRow Is Nothing Then Return
            Dim id = dgv.CurrentRow.Cells("MaDoDung").Value
            Database.ExecuteNonQuery("DELETE FROM DoDung WHERE MaDoDung=@ID",
                                     New List(Of SqlParameter) From {New SqlParameter("@ID", id)})
            LoadData(Nothing, Nothing)
        End Sub
    End Class
End Namespace
